package com.jdbc.spring.repo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	
	public String test() {
		
		return "Learning springboot jdbcTemplate to connect MySQL database.";
	}


	public String insertRecord() {
		
		String insertSql = "insert into active_users(userid, firstname, lastname, status,email, phone) values ('abc000', 'okay', 'computing', 'A', 'okaycomputing@gmail.com', '9988771122') ";
		jdbcTemplate.execute(insertSql);
		
		return "record inserted";
		
	}

	
	
}
